#!/bin/bash


URL="https://www.youtube.com/watch?v=dQw4w9WgXcQ"

if command -v xdg-open > /dev/null; then
  xdg-open "$URL"
elif command -v gnome-open > /dev/null; then
  gnome-open "$URL"
elif command -v open > /dev/null; then
  open "$URL"
else
  echo "Impossible d'ouvrir le navigateur. Veuillez ouvrir cette URL manuellement : $URL"
fi
